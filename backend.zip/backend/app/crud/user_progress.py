from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy import update
from uuid import UUID
from datetime import datetime, timedelta

from app.models.user_progress import UserProgress
from app.schemas.progress import UserProgressCreate


# Функция вычисления следующей даты повторения по числам Фибоначчи
def calculate_next_due_date(repetition_count: int) -> datetime:
    fibonacci_days = [1, 2, 3, 5, 8, 13, 21]
    days = fibonacci_days[min(repetition_count, len(fibonacci_days) - 1)]
    return datetime.utcnow() + timedelta(days=days)


# Сохранение или обновление прогресса
async def create_or_update_progress(db: AsyncSession, data: UserProgressCreate) -> UserProgress:
    stmt = select(UserProgress).where(
        UserProgress.user_id == data.user_id,
        UserProgress.question_id == data.question_id,
        UserProgress.country == data.country,
        UserProgress.language == data.language
    )
    result = await db.execute(stmt)
    existing = result.scalars().first()

    now = datetime.utcnow()

    if existing:
        existing.repetition_count += 1
        existing.is_correct = data.is_correct
        existing.last_answered_at = now
        existing.next_due_at = calculate_next_due_date(existing.repetition_count)
    else:
        existing = UserProgress(
            user_id=data.user_id,
            question_id=data.question_id,
            is_correct=data.is_correct,
            country=data.country,
            language=data.language,
            repetition_count=1,
            last_answered_at=now,
            next_due_at=calculate_next_due_date(1),
        )
        db.add(existing)

    await db.commit()
    await db.refresh(existing)
    return existing


# Получить весь прогресс пользователя
async def get_progress_for_user(db: AsyncSession, user_id: UUID):
    stmt = select(UserProgress).where(UserProgress.user_id == user_id)
    result = await db.execute(stmt)
    return result.scalars().all()
