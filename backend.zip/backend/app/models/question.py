from sqlalchemy import Column, Integer, Text, JSON
from app.database import Base

class Question(Base):
    __tablename__ = "questions"

    id = Column(Integer, primary_key=True, index=True)
    data = Column(JSON, nullable=False)  # JSONB — в PostgreSQL
    topic = Column(Text, nullable=False)
    country = Column(Text, nullable=False)
    language = Column(Text, nullable=False)